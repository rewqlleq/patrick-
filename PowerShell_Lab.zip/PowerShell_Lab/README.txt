Папка PowerShell_Lab подготовлена для лабораторной работы.
Структура:
- Files\  (текстовые результаты)
- Reports\ (CSV, отчёты)
- Screenshots\ (скриншоты шагов: step01.png ... step15.png)
- Step01..Step15\ (в каждой папке: commands.ps1, output.txt, note.txt)

Скопируй папку в C:\PowerShell_Lab на целевой машине или распакуй архив и используй директорию.
