
# === Step 02: Работа с пользователями и группами ===
# Просмотр локальных пользователей
Get-LocalUser

# Создание нового пользователя (пример)
# New-LocalUser -Name "student" -Password (Read-Host -AsSecureString "Введите пароль")

# Просмотр локальных групп
Get-LocalGroup
