
# === Step 05: Работа со службами ===
# Просмотр списка служб
Get-Service

# Экспорт служб в CSV
Get-Service | Export-Csv "C:\PowerShell_Lab\Files\services.csv" -NoTypeInformation
