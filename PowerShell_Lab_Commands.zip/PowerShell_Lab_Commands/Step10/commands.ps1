
# === Step 10: Планировщик заданий ===
# Просмотр задач планировщика
Get-ScheduledTask

# Создание новой простой задачи (пример)
# Register-ScheduledTask -Action (New-ScheduledTaskAction -Execute "notepad.exe") -Trigger (New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1)) -TaskName "OpenNotepad"
