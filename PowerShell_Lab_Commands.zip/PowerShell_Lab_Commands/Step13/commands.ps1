
# === Step 13: Работа с CSV и текстом ===
# Пример чтения CSV
Import-Csv "C:\PowerShell_Lab\Files\services.csv"

# Пример чтения текстового файла
Get-Content "C:\PowerShell_Lab\Files\env.txt"
