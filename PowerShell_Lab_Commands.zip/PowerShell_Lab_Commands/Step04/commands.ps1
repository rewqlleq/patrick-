
# === Step 04: Политики безопасности ===
# Экспорт локальных политик безопасности в текстовый файл
secedit /export /cfg "C:\PowerShell_Lab\Files\policy.txt"
