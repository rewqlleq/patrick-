
# === Step 01: Информация о системе ===
# Просмотр основной информации о компьютере
Get-ComputerInfo | Select-Object CsName, OsName, OsVersion, OsArchitecture

# Сохранение информации в файл
Get-ComputerInfo | Out-File "C:\PowerShell_Lab\Files\system_info.txt"
