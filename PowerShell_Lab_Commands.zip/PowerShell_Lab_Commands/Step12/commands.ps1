
# === Step 12: Модули PowerShell ===
# Просмотр установленных модулей
Get-Module -ListAvailable

# Импорт модуля (пример)
# Import-Module NetSecurity
