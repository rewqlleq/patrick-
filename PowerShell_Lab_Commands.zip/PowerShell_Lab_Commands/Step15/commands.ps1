
# === Step 15: Итоговый отчёт ===
# Создание текстового отчёта
"Лабораторная работа завершена успешно." | Out-File "C:\PowerShell_Lab\Reports\final_report.txt"
