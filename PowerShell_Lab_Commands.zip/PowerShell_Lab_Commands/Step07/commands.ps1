
# === Step 07: Работа с файлами и каталогами ===
# Просмотр содержимого папки
Get-ChildItem "C:\PowerShell_Lab"

# Создание текстового файла
New-Item -Path "C:\PowerShell_Lab\Files\example.txt" -ItemType File
