
# === Step 09: Журналы событий ===
# Просмотр последних системных событий
Get-EventLog -LogName System -Newest 10

# Сохранение событий в файл
Get-EventLog -LogName System -Newest 50 | Out-File "C:\PowerShell_Lab\Files\events.txt"
