PowerShell_Lab_Commands
15 шагов с командами PowerShell для учебного задания.
Каждая папка StepXX содержит файл commands.ps1, output.txt и note.txt.
