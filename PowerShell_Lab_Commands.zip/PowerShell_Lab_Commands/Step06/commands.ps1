
# === Step 06: Процессы ===
# Просмотр всех процессов
Get-Process

# Экспорт процессов в CSV
Get-Process | Export-Csv "C:\PowerShell_Lab\Files\procs.csv" -NoTypeInformation
