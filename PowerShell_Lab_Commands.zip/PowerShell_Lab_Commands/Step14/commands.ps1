
# === Step 14: Архивация ===
# Создание архива из папки Files
Compress-Archive -Path "C:\PowerShell_Lab\Files" -DestinationPath "C:\PowerShell_Lab\Reports\FilesBackup.zip"
