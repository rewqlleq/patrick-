
# === Step 03: Переменные среды ===
# Просмотр всех переменных среды
Get-ChildItem Env:

# Экспорт переменных среды в файл
Get-ChildItem Env: | Out-File "C:\PowerShell_Lab\Files\env.txt"
