
# === Step 11: Алиасы и функции ===
# Просмотр алиасов
Get-Alias

# Сохранение алиасов в файл
Get-Alias | Out-File "C:\PowerShell_Lab\Files\aliases.txt"
